# Fieldstock — Clothing Catalog & Cart

A small e-commerce front end for a clothing brand (pants, shirts, bags, outerwear, shoes). Browse the
catalog, filter and search, and add items to a bag that slides out as a cart drawer — with a full cart
page for checkout-style review. Built for **Option 5: Mini E-Commerce Product Catalog & Cart**.

## Features implemented

- Product catalog rendered from local mock data (13 items across 5 categories).
- Live search by name/category and category filter chips.
- Add-to-bag from any product card, with quantity handling for repeat adds.
- **Slide-out cart drawer** (opens automatically on add, or via the "Bag" button) showing line items,
  quantity controls, and a subtotal.
- Dedicated **Cart page** (`/cart`) with a full summary: subtotal, shipping rule, and total.
- Cart persists across page refreshes using `localStorage`.
- Empty states for an empty bag and for a search with no matches.
- Fully responsive layout: 4-column grid on desktop down to a single column and a full-width drawer on
  mobile.

## Technologies used

- [React](https://react.dev/) 18 (functional components + hooks only)
- [Vite](https://vitejs.dev/) as the build tool / dev server
- [React Router](https://reactrouter.com/) for the Catalog and Cart routes
- Plain CSS (no framework), with Fraunces + Work Sans from Google Fonts
- Browser `localStorage` for cart persistence

## Project structure

```
wardrobe/
├── src/
│   ├── components/
│   │   ├── Navbar.jsx
│   │   ├── ProductCard.jsx
│   │   ├── ProductGrid.jsx
│   │   ├── SearchFilterBar.jsx
│   │   ├── CartDrawer.jsx
│   │   └── CartItem.jsx
│   ├── context/
│   │   └── CartContext.jsx      # useState + useEffect, shared via useCart()
│   ├── data/
│   │   └── products.js          # mock product catalog
│   ├── pages/
│   │   ├── Catalog.jsx
│   │   └── CartPage.jsx
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── index.html
├── package.json
└── vite.config.js
```

## Setup instructions

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

To build for production:

```bash
npm run build
npm run preview
```

## Screenshots

> Add 2–3 screenshots here once you've run the app locally, e.g.:
>
> `![Catalog view](./screenshots/catalog.png)`
> `![Cart drawer open](./screenshots/drawer.png)`
> `![Cart page](./screenshots/cart-page.png)`

## Known limitations

- Product data is local/mock rather than pulled from a live API (matches the assignment's allowed
  "local mock data or a public API" option).
- No sort-by-price/name control yet (listed as a stretch goal).
- Checkout is a summary screen only — no real payment processing.
