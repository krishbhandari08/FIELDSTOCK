export default function ProductCard({ product, onAdd }) {
  return (
    <article className="product-card">
      <div className="product-card__swatch" style={{ backgroundColor: product.swatch }}>
        <span className="product-card__category">{product.category}</span>
      </div>

      <div className="product-card__body">
        <h3>{product.name}</h3>
        <p className="product-card__meta">{product.color}</p>
        <p className="product-card__price">${product.price}</p>
        <button type="button" onClick={() => onAdd(product)}>
          Add to bag
        </button>
      </div>
    </article>
  )
}
