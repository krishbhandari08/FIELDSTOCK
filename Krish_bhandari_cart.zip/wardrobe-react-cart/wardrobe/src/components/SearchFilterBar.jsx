export default function SearchFilterBar({
  categories,
  searchTerm,
  onSearchChange,
  activeCategory,
  onCategoryChange,
}) {
  function handleSubmit(event) {
    // Prevent a full page reload; state already updates live via onChange,
    // this just gives the form a proper submit affordance (e.g. pressing Enter).
    event.preventDefault()
  }

  return (
    <div className="filter-bar">
      <form className="search-form" onSubmit={handleSubmit} role="search">
        <label htmlFor="search" className="visually-hidden">
          Search products
        </label>
        <input
          id="search"
          type="text"
          placeholder="Search pants, shirts, bags…"
          value={searchTerm}
          onChange={(event) => onSearchChange(event.target.value)}
        />
      </form>

      <div className="category-chips">
        <button
          type="button"
          className={activeCategory === 'All' ? 'chip chip--active' : 'chip'}
          onClick={() => onCategoryChange('All')}
        >
          All
        </button>
        {categories.map((category) => (
          <button
            key={category}
            type="button"
            className={activeCategory === category ? 'chip chip--active' : 'chip'}
            onClick={() => onCategoryChange(category)}
          >
            {category}
          </button>
        ))}
      </div>
    </div>
  )
}
