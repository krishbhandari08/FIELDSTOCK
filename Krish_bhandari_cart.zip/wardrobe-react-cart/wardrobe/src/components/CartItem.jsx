export default function CartItem({ item, onUpdateQuantity, onRemove }) {
  return (
    <div className="cart-item">
      <div className="cart-item__swatch" style={{ backgroundColor: item.swatch }} />

      <div className="cart-item__info">
        <p className="cart-item__name">{item.name}</p>
        <p className="cart-item__meta">{item.color}</p>

        <div className="cart-item__quantity">
          <button type="button" onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} aria-label="Decrease quantity">
            −
          </button>
          <span>{item.quantity}</span>
          <button type="button" onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} aria-label="Increase quantity">
            +
          </button>
        </div>
      </div>

      <div className="cart-item__right">
        <p className="cart-item__price">${(item.price * item.quantity).toFixed(2)}</p>
        <button type="button" className="cart-item__remove" onClick={() => onRemove(item.id)}>
          Remove
        </button>
      </div>
    </div>
  )
}
