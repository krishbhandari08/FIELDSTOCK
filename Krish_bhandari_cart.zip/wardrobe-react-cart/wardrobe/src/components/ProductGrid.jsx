import ProductCard from './ProductCard'

export default function ProductGrid({ products, onAdd }) {
  if (products.length === 0) {
    return (
      <div className="empty-state">
        <h3>No pieces match that search</h3>
        <p>Try a different keyword, or clear the category filter.</p>
      </div>
    )
  }

  return (
    <div className="product-grid">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} onAdd={onAdd} />
      ))}
    </div>
  )
}
