import { Link } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import CartItem from './CartItem'

export default function CartDrawer() {
  const { items, isDrawerOpen, setDrawerOpen, updateQuantity, removeItem, subtotal } = useCart()

  return (
    <>
      {/* Backdrop — clicking it closes the drawer, same as the close button */}
      <div
        className={isDrawerOpen ? 'drawer-backdrop drawer-backdrop--visible' : 'drawer-backdrop'}
        onClick={() => setDrawerOpen(false)}
        aria-hidden="true"
      />

      <aside
        className={isDrawerOpen ? 'cart-drawer cart-drawer--open' : 'cart-drawer'}
        aria-hidden={!isDrawerOpen}
      >
        <div className="cart-drawer__header">
          <h2>Your bag</h2>
          <button type="button" onClick={() => setDrawerOpen(false)} aria-label="Close cart">
            ×
          </button>
        </div>

        {items.length === 0 ? (
          <div className="cart-drawer__empty">
            <p>Your bag is empty.</p>
            <button type="button" onClick={() => setDrawerOpen(false)}>
              Keep browsing
            </button>
          </div>
        ) : (
          <>
            <div className="cart-drawer__items">
              {items.map((item) => (
                <CartItem key={item.id} item={item} onUpdateQuantity={updateQuantity} onRemove={removeItem} />
              ))}
            </div>

            <div className="cart-drawer__footer">
              <div className="cart-drawer__subtotal">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <Link to="/cart" className="button button--primary" onClick={() => setDrawerOpen(false)}>
                View full cart
              </Link>
            </div>
          </>
        )}
      </aside>
    </>
  )
}
