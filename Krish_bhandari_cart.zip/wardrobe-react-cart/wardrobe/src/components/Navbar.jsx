import { Link } from 'react-router-dom'
import { useCart } from '../context/CartContext'

export default function Navbar() {
  const { itemCount, setDrawerOpen } = useCart()

  return (
    <header className="navbar">
      <Link to="/" className="wordmark">
        Fieldstock
      </Link>

      <nav className="nav-links">
        <Link to="/">Catalog</Link>
        <Link to="/cart">Cart</Link>
      </nav>

      <button
        type="button"
        className="cart-toggle"
        onClick={() => setDrawerOpen(true)}
        aria-label={`Open cart, ${itemCount} item${itemCount === 1 ? '' : 's'}`}
      >
        Bag
        {itemCount > 0 && <span className="cart-toggle__badge">{itemCount}</span>}
      </button>
    </header>
  )
}
