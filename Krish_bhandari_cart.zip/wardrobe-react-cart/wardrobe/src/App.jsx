import { Route, Routes } from 'react-router-dom'
import { CartProvider } from './context/CartContext'
import Navbar from './components/Navbar'
import CartDrawer from './components/CartDrawer'
import Catalog from './pages/Catalog'
import CartPage from './pages/CartPage'

export default function App() {
  return (
    <CartProvider>
      <Navbar />
      <Routes>
        <Route path="/" element={<Catalog />} />
        <Route path="/cart" element={<CartPage />} />
      </Routes>
      <CartDrawer />
    </CartProvider>
  )
}
