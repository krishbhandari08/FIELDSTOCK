import { Link } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import CartItem from '../components/CartItem'

export default function CartPage() {
  const { items, updateQuantity, removeItem, clearCart, subtotal, itemCount } = useCart()

  const shipping = subtotal > 0 && subtotal < 100 ? 8 : 0
  const total = subtotal + shipping

  if (items.length === 0) {
    return (
      <main className="cart-page cart-page--empty">
        <h1>Your bag is empty</h1>
        <p>Nothing in here yet. Go find something worth carrying.</p>
        <Link to="/" className="button button--primary">
          Back to catalog
        </Link>
      </main>
    )
  }

  return (
    <main className="cart-page">
      <h1>Your bag ({itemCount})</h1>

      <div className="cart-page__layout">
        <div className="cart-page__items">
          {items.map((item) => (
            <CartItem key={item.id} item={item} onUpdateQuantity={updateQuantity} onRemove={removeItem} />
          ))}
          <button type="button" className="cart-page__clear" onClick={clearCart}>
            Clear bag
          </button>
        </div>

        <aside className="cart-page__summary">
          <h2>Summary</h2>
          <div className="summary-row">
            <span>Subtotal</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>
          <div className="summary-row">
            <span>Shipping</span>
            <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
          </div>
          <div className="summary-row summary-row--total">
            <span>Total</span>
            <span>${total.toFixed(2)}</span>
          </div>
          <button type="button" className="button button--primary button--block">
            Checkout
          </button>
          <p className="cart-page__note">Checkout is a summary screen only — no real payment is processed.</p>
        </aside>
      </div>
    </main>
  )
}
