import { useEffect, useMemo, useState } from 'react'
import products from '../data/products'
import { useCart } from '../context/CartContext'
import SearchFilterBar from '../components/SearchFilterBar'
import ProductGrid from '../components/ProductGrid'

const categories = [...new Set(products.map((p) => p.category))]

export default function Catalog() {
  const { addItem } = useCart()
  const [searchTerm, setSearchTerm] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [visibleProducts, setVisibleProducts] = useState(products)

  // Recompute the visible list whenever the search term or category changes.
  // (Small dataset here, but this is the same shape you'd use to re-run a
  // fetch or re-filter data pulled from an API.)
  useEffect(() => {
    const term = searchTerm.trim().toLowerCase()

    const next = products.filter((product) => {
      const matchesCategory = activeCategory === 'All' || product.category === activeCategory
      const matchesSearch =
        term === '' ||
        product.name.toLowerCase().includes(term) ||
        product.category.toLowerCase().includes(term)
      return matchesCategory && matchesSearch
    })

    setVisibleProducts(next)
  }, [searchTerm, activeCategory])

  const resultCount = useMemo(() => visibleProducts.length, [visibleProducts])

  return (
    <main className="catalog">
      <section className="catalog__intro">
        <h1>Clothing built to be worn, not just owned</h1>
        <p>Pants, shirts, bags, and outerwear in a small, considered range. Everything ships in two days.</p>
      </section>

      <SearchFilterBar
        categories={categories}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
      />

      <p className="catalog__count">
        {resultCount} {resultCount === 1 ? 'item' : 'items'}
      </p>

      <ProductGrid products={visibleProducts} onAdd={addItem} />
    </main>
  )
}
